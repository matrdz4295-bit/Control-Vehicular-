param(
  [int]$Port = 8787
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web.Extensions

$script:Root = $PSScriptRoot
$script:DataDirectory = Join-Path $script:Root 'datos-compartidos'
$script:UploadDirectory = Join-Path $script:DataDirectory 'escaneos'
$script:DataPath = Join-Path $script:DataDirectory 'sicoprev.json'
$script:Serializer = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$script:Serializer.MaxJsonLength = 40000000
$script:Serializer.RecursionLimit = 100
$script:Sessions = @{}

New-Item -ItemType Directory -Path $script:UploadDirectory -Force | Out-Null

function New-Store {
  return @{
    users = @()
    requests = @()
    vehicles = @()
    logs = @()
    attachments = @()
  }
}

if (Test-Path $script:DataPath) {
  $script:Store = $script:Serializer.DeserializeObject([System.IO.File]::ReadAllText($script:DataPath, [System.Text.Encoding]::UTF8))
  foreach ($key in @('users', 'requests', 'vehicles', 'logs', 'attachments')) {
    if (-not $script:Store.ContainsKey($key)) { $script:Store[$key] = @() }
  }
} else {
  $script:Store = New-Store
}

function Save-Store {
  $json = $script:Serializer.Serialize($script:Store)
  $temporaryPath = "$($script:DataPath).tmp"
  [System.IO.File]::WriteAllText($temporaryPath, $json, (New-Object System.Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $temporaryPath -Destination $script:DataPath -Force
}

function Send-Json($Context, [int]$StatusCode, $Value) {
  $json = $script:Serializer.Serialize($Value)
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.ContentType = 'application/json; charset=utf-8'
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.Headers['X-Content-Type-Options'] = 'nosniff'
  $Context.Response.ContentLength64 = $bytes.Length
  $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Context.Response.Close()
}

function Send-Bytes($Context, [int]$StatusCode, [string]$ContentType, [byte[]]$Bytes, [string]$DownloadName = '') {
  $Context.Response.StatusCode = $StatusCode
  $Context.Response.ContentType = $ContentType
  $Context.Response.Headers['Cache-Control'] = 'no-store'
  $Context.Response.Headers['X-Content-Type-Options'] = 'nosniff'
  $Context.Response.ContentLength64 = $Bytes.Length
  if ($DownloadName) {
    $safeName = [System.Uri]::EscapeDataString($DownloadName)
    $Context.Response.AppendHeader('Content-Disposition', "attachment; filename*=UTF-8''$safeName")
  }
  $Context.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
  $Context.Response.Close()
}

function Read-Json($Request) {
  $reader = New-Object System.IO.StreamReader($Request.InputStream, [System.Text.Encoding]::UTF8)
  try {
    $text = $reader.ReadToEnd()
    if (-not $text) { return @{} }
    return $script:Serializer.DeserializeObject($text)
  } finally {
    $reader.Dispose()
  }
}

function Get-RandomHex([int]$Length = 24) {
  $bytes = New-Object byte[] $Length
  $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
  return [System.BitConverter]::ToString($bytes).Replace('-', '').ToLowerInvariant()
}

function Get-PasswordText([System.Security.SecureString]$Password) {
  $pointer = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)
  try { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
  finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

function New-PasswordRecord([System.Security.SecureString]$Password) {
  $salt = New-Object byte[] 16
  $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try { $generator.GetBytes($salt) } finally { $generator.Dispose() }
  $passwordText = Get-PasswordText $Password
  $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($passwordText, $salt, 150000)
  try { $hash = $derive.GetBytes(32) } finally { $derive.Dispose() }
  $passwordText = $null
  return @{ salt = [Convert]::ToBase64String($salt); passwordHash = [Convert]::ToBase64String($hash) }
}

function Test-Password([System.Security.SecureString]$Password, [string]$Salt, [string]$ExpectedHash) {
  $passwordText = Get-PasswordText $Password
  $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($passwordText, [Convert]::FromBase64String($Salt), 150000)
  try { $actual = [Convert]::ToBase64String($derive.GetBytes(32)) } finally { $derive.Dispose() }
  $passwordText = $null
  return [System.String]::Equals($actual, $ExpectedHash, [System.StringComparison]::Ordinal)
}

function Get-PublicUser($User) {
  return @{ id = $User.id; name = $User.name; username = $User.username; role = $User.role }
}

function Get-CurrentUser($Context) {
  $cookie = $Context.Request.Cookies['SICOPREV_SESSION']
  if (-not $cookie -or -not $script:Sessions.ContainsKey($cookie.Value)) { return $null }
  $userId = $script:Sessions[$cookie.Value]
  foreach ($user in $script:Store['users']) {
    if ($user['id'] -eq $userId) { return $user }
  }
  return $null
}

function Assert-User($Context) {
  $user = Get-CurrentUser $Context
  if (-not $user) {
    Send-Json $Context 401 @{ error = 'Inicia sesión para continuar.' }
    return $null
  }
  return $user
}

function Get-SharedState {
  return @{
    requests = @($script:Store['requests'])
    vehicles = @($script:Store['vehicles'])
    logs = @($script:Store['logs'])
    attachments = @($script:Store['attachments'])
  }
}

function Set-CollectionChanges([string]$Collection, $Changes) {
  $items = @($script:Store[$Collection])
  foreach ($deletedId in @($Changes['delete'])) {
    $items = @($items | Where-Object { $_['id'] -ne $deletedId })
  }
  foreach ($record in @($Changes['upsert'])) {
    $match = -1
    for ($index = 0; $index -lt $items.Count; $index++) {
      if ($items[$index]['id'] -eq $record['id']) { $match = $index; break }
    }
    if ($match -ge 0) { $items[$match] = $record }
    else { $items = @($items) + @($record) }
  }
  $script:Store[$Collection] = $items
}

function Invoke-Api($Context) {
  $request = $Context.Request
  $path = $request.Url.AbsolutePath.TrimEnd('/')
  if (-not $path) { $path = '/' }
  $method = $request.HttpMethod

  if ($path -eq '/api/status' -and $method -eq 'GET') {
    Send-Json $Context 200 @{ configured = (@($script:Store['users']).Count -gt 0) }
    return
  }

  if ($path -eq '/api/setup' -and $method -eq 'POST') {
    if (@($script:Store['users']).Count -gt 0) { Send-Json $Context 409 @{ error = 'La cuenta administradora ya fue configurada.' }; return }
    $body = Read-Json $request
    $username = ([string]$body['username']).Trim().ToLowerInvariant()
    $password = [string]$body['password']
    $name = ([string]$body['name']).Trim()
    if ($username.Length -lt 3 -or $password.Length -lt 12 -or -not $name) { Send-Json $Context 400 @{ error = 'Completa los datos; la contraseña debe tener al menos 12 caracteres.' }; return }
    $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
    $credential = New-PasswordRecord $securePassword
    $securePassword.Dispose()
    $user = @{ id = Get-RandomHex 12; name = $name; username = $username; role = 'admin'; salt = $credential.salt; passwordHash = $credential.passwordHash }
    $script:Store['users'] = @($user)
    Save-Store
    $token = Get-RandomHex 32
    $script:Sessions[$token] = $user.id
    $Context.Response.AppendHeader('Set-Cookie', "SICOPREV_SESSION=$token; Path=/; HttpOnly; SameSite=Strict")
    Send-Json $Context 201 (Get-PublicUser $user)
    return
  }

  if ($path -eq '/api/login' -and $method -eq 'POST') {
    $body = Read-Json $request
    $username = ([string]$body['username']).Trim().ToLowerInvariant()
    $user = $null
    foreach ($candidate in $script:Store['users']) {
      if ($candidate['username'] -eq $username) { $user = $candidate; break }
    }
    $securePassword = ConvertTo-SecureString ([string]$body['password']) -AsPlainText -Force
    $validPassword = $user -and (Test-Password $securePassword $user['salt'] $user['passwordHash'])
    $securePassword.Dispose()
    if (-not $validPassword) { Send-Json $Context 401 @{ error = 'Usuario o contraseña incorrectos.' }; return }
    $token = Get-RandomHex 32
    $script:Sessions[$token] = $user.id
    $Context.Response.AppendHeader('Set-Cookie', "SICOPREV_SESSION=$token; Path=/; HttpOnly; SameSite=Strict")
    Send-Json $Context 200 (Get-PublicUser $user)
    return
  }

  if ($path -eq '/api/logout' -and $method -eq 'POST') {
    $cookie = $request.Cookies['SICOPREV_SESSION']
    if ($cookie) { $script:Sessions.Remove($cookie.Value) }
    $Context.Response.AppendHeader('Set-Cookie', 'SICOPREV_SESSION=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
    Send-Json $Context 200 @{ ok = $true }
    return
  }

  $currentUser = Assert-User $Context
  if (-not $currentUser) { return }

  if ($path -eq '/api/me' -and $method -eq 'GET') { Send-Json $Context 200 (Get-PublicUser $currentUser); return }

  if ($path -eq '/api/users' -and $method -eq 'GET') {
    if ($currentUser['role'] -ne 'admin') { Send-Json $Context 403 @{ error = 'Solo la cuenta administradora puede ver los accesos.' }; return }
    Send-Json $Context 200 @($script:Store['users'] | ForEach-Object { Get-PublicUser $_ })
    return
  }

  if ($path -eq '/api/users' -and $method -eq 'POST') {
    if ($currentUser['role'] -ne 'admin') { Send-Json $Context 403 @{ error = 'Solo la cuenta administradora puede autorizar usuarios.' }; return }
    $body = Read-Json $request
    $username = ([string]$body['username']).Trim().ToLowerInvariant()
    $role = [string]$body['role']
    if ($role -notin @('capturista', 'consulta')) { Send-Json $Context 400 @{ error = 'El perfil debe ser capturista o consulta.' }; return }
    if ($username.Length -lt 3 -or ([string]$body['password']).Length -lt 12 -or -not ([string]$body['name']).Trim()) { Send-Json $Context 400 @{ error = 'Completa los datos; la contraseña debe tener al menos 12 caracteres.' }; return }
    foreach ($existing in $script:Store['users']) {
      if ($existing['username'] -eq $username) { Send-Json $Context 409 @{ error = 'Ese usuario ya existe.' }; return }
    }
    $securePassword = ConvertTo-SecureString ([string]$body['password']) -AsPlainText -Force
    $credential = New-PasswordRecord $securePassword
    $securePassword.Dispose()
    $user = @{ id = Get-RandomHex 12; name = ([string]$body['name']).Trim(); username = $username; role = $role; salt = $credential.salt; passwordHash = $credential.passwordHash }
    $script:Store['users'] = @($script:Store['users']) + @($user)
    Save-Store
    Send-Json $Context 201 (Get-PublicUser $user)
    return
  }

  if ($path -match '^/api/users/([a-f0-9]+)$' -and $method -eq 'DELETE') {
    if ($currentUser['role'] -ne 'admin') { Send-Json $Context 403 @{ error = 'Solo la cuenta administradora puede retirar accesos.' }; return }
    $userId = $Matches[1]
    if ($userId -eq $currentUser['id']) { Send-Json $Context 400 @{ error = 'No puedes eliminar la cuenta administradora activa.' }; return }
    $script:Store['users'] = @($script:Store['users'] | Where-Object { $_['id'] -ne $userId })
    Save-Store
    Send-Json $Context 200 @{ ok = $true }
    return
  }

  if ($path -eq '/api/data' -and $method -eq 'GET') { Send-Json $Context 200 (Get-SharedState); return }

  if ($path -eq '/api/data' -and $method -eq 'POST') {
    if ($currentUser['role'] -notin @('admin', 'capturista')) { Send-Json $Context 403 @{ error = 'Tu perfil no puede modificar los registros.' }; return }
    $body = Read-Json $request
    foreach ($collection in @('requests', 'vehicles', 'logs', 'attachments')) {
      if ($body['changes'].ContainsKey($collection)) { Set-CollectionChanges $collection $body['changes'][$collection] }
    }
    Save-Store
    Send-Json $Context 200 (Get-SharedState)
    return
  }

  if ($path -eq '/api/attachments' -and $method -eq 'POST') {
    if ($currentUser['role'] -notin @('admin', 'capturista')) { Send-Json $Context 403 @{ error = 'Tu perfil no puede adjuntar escaneos.' }; return }
    $body = Read-Json $request
    try { $bytes = [Convert]::FromBase64String([string]$body['contentBase64']) } catch { Send-Json $Context 400 @{ error = 'El archivo no tiene un formato válido.' }; return }
    if ($bytes.Length -gt 12000000) { Send-Json $Context 413 @{ error = 'El archivo supera el límite de 12 MB.' }; return }
    $id = Get-RandomHex 16
    $fileName = [System.IO.Path]::GetFileName([string]$body['fileName'])
    $extension = [System.IO.Path]::GetExtension($fileName).ToLowerInvariant()
    if ($extension -notin @('.pdf', '.jpg', '.jpeg', '.png')) { Send-Json $Context 415 @{ error = 'Solo se permiten archivos PDF, JPG y PNG.' }; return }
    $contentType = switch ($extension) {
      '.pdf' { 'application/pdf' }
      '.jpg' { 'image/jpeg' }
      '.jpeg' { 'image/jpeg' }
      '.png' { 'image/png' }
    }
    [System.IO.File]::WriteAllBytes((Join-Path $script:UploadDirectory $id), $bytes)
    $attachment = @{ id = $id; fileName = $fileName; contentType = $contentType; uploadedBy = $currentUser['name']; uploadedAt = [DateTime]::UtcNow.ToString('o') }
    $script:Store['attachments'] = @($script:Store['attachments']) + @($attachment)
    Save-Store
    Send-Json $Context 201 $attachment
    return
  }

  if ($path -match '^/api/attachments/([a-f0-9]+)$' -and $method -eq 'GET') {
    $attachmentId = $Matches[1]
    $attachment = $script:Store['attachments'] | Where-Object { $_['id'] -eq $attachmentId } | Select-Object -First 1
    $filePath = Join-Path $script:UploadDirectory $attachmentId
    if (-not $attachment -or -not (Test-Path $filePath)) { Send-Json $Context 404 @{ error = 'No se encontró el escaneo.' }; return }
    $bytes = [System.IO.File]::ReadAllBytes($filePath)
    Send-Bytes $Context 200 $attachment['contentType'] $bytes $attachment['fileName']
    return
  }

  Send-Json $Context 404 @{ error = 'Ruta no encontrada.' }
}

function Send-StaticFile($Context) {
  $relativePath = [System.Uri]::UnescapeDataString($Context.Request.Url.AbsolutePath.TrimStart('/'))
  if (-not $relativePath) { $relativePath = 'index.html' }
  if ($relativePath -notin @('index.html', 'estilos.css', 'funciones.js')) {
    Send-Bytes $Context 404 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('No encontrado'))
    return
  }
  $fullPath = Join-Path $script:Root $relativePath
  $extension = [System.IO.Path]::GetExtension($fullPath).ToLowerInvariant()
  $contentType = switch ($extension) {
    '.html' { 'text/html; charset=utf-8' }
    '.css' { 'text/css; charset=utf-8' }
    '.js' { 'application/javascript; charset=utf-8' }
    '.svg' { 'image/svg+xml' }
    default { 'application/octet-stream' }
  }
  $bytes = [System.IO.File]::ReadAllBytes($fullPath)
  Send-Bytes $Context 200 $contentType $bytes
}

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
Write-Host "SICOPREV disponible en http://localhost:$Port/"
Write-Host 'Para otros equipos, usa la dirección IP de esta computadora y permite el puerto en el firewall.'
Write-Host "Datos compartidos: $script:DataPath"
Write-Host 'Detén el servidor con Ctrl+C.'

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    try {
      if ($context.Request.Url.AbsolutePath.StartsWith('/api/')) { Invoke-Api $context }
      else { Send-StaticFile $context }
    } catch {
      Write-Warning $_.Exception.Message
      if ($context.Response.OutputStream.CanWrite) {
        try { Send-Json $context 500 @{ error = 'Error interno del servidor.' } } catch { $context.Response.Close() }
      }
    }
  }
} finally {
  if ($listener.IsListening) { $listener.Stop() }
  $listener.Close()
}