const STORAGE_KEY = 'sicoprev-data-v1';
const STATUSES = ['Pendiente', 'Autorizado', 'En curso', 'Completado', 'Cancelado'];
const state = loadState();
let users = [];
let currentUser = null;
let toastTimer;
let liveRefreshTimer;
let saveQueue = Promise.resolve();
let serverSnapshot = { requests: [], vehicles: [], logs: [], attachments: [] };

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return { requests: Array.isArray(saved.requests) ? saved.requests : [], vehicles: Array.isArray(saved.vehicles) ? saved.vehicles : [], logs: Array.isArray(saved.logs) ? saved.logs : [], attachments: Array.isArray(saved.attachments) ? saved.attachments : [] };
  } catch {
    return { requests: [], vehicles: [], logs: [], attachments: [] };
  }
}
async function apiRequest(path, options = {}) {
  const headers = { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers };
  const response = await fetch(path, { ...options, headers, credentials: 'same-origin' });
  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json') ? await response.json() : null;
  if (!response.ok) throw new Error(payload?.error || `Error del servidor (${response.status}).`);
  return payload;
}
function copyCollections(source) {
  return Object.fromEntries(['requests', 'vehicles', 'logs', 'attachments'].map(collection => [collection, JSON.parse(JSON.stringify(source[collection] || []))]));
}
function applySharedState(shared) {
  for (const collection of ['requests', 'vehicles', 'logs', 'attachments']) state[collection] = Array.isArray(shared[collection]) ? shared[collection] : [];
  serverSnapshot = copyCollections(state);
}
function buildChanges() {
  const changes = {};
  for (const collection of ['requests', 'vehicles', 'logs', 'attachments']) {
    const previous = serverSnapshot[collection] || [];
    const previousById = new Map(previous.map(item => [item.id, item]));
    const currentIds = new Set(state[collection].map(item => item.id));
    const upsert = state[collection].filter(item => JSON.stringify(previousById.get(item.id)) !== JSON.stringify(item));
    const deleted = previous.filter(item => !currentIds.has(item.id)).map(item => item.id);
    if (upsert.length || deleted.length) changes[collection] = { upsert, delete: deleted };
  }
  return changes;
}
function persist() {
  const changes = buildChanges();
  if (!Object.keys(changes).length) return saveQueue;
  saveQueue = saveQueue.catch(() => {}).then(async () => {
    const shared = await apiRequest('/api/data', { method: 'POST', body: JSON.stringify({ changes }) });
    applySharedState(shared);
    render();
  }).catch(error => showToast(error.message || 'No se pudieron guardar los cambios en el servidor.'));
  return saveQueue;
}
async function refreshSharedState() {
  await saveQueue.catch(() => {});
  applySharedState(await apiRequest('/api/data'));
  if (currentUser?.role === 'admin') users = await apiRequest('/api/users');
  render();
}
function escapeHtml(value = '') { return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]); }
function todayISO() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function formatDate(value) {
  if (!value) return '—';
  const parsed = new Date(`${value}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? '—' : new Intl.DateTimeFormat('es-MX', { day: '2-digit', month: 'short', year: 'numeric' }).format(parsed);
}
function formatDateTime(value) {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '—';
  return new Intl.DateTimeFormat('es-MX', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(parsed);
}
function formatKm(value) {
  if (value === '' || value === null || value === undefined || !Number.isFinite(Number(value))) return '—';
  return `${new Intl.NumberFormat('es-MX').format(Number(value))} km`;
}
function makeId(prefix) { return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`.toUpperCase(); }
function nextFolio() {
  const year = new Date().getFullYear();
  const count = state.requests.filter(request => request.folio?.startsWith(`SP-${year}-`)).length + 1;
  return `SP-${year}-${String(count).padStart(4, '0')}`;
}
function addLog(type, reference, action, detail, attachments = []) { state.logs.unshift({ id: makeId('LOG'), timestamp: new Date().toISOString(), type, reference, action, detail, attachments, user: currentUser?.name || 'Sistema' }); }
function vehicleFor(id) { return state.vehicles.find(vehicle => vehicle.id === id); }
function vehicleReference(vehicle) { return vehicle ? `No. ${vehicle.unitNumber || 's/n'} · ${vehicle.plate}` : 'Sin unidad'; }
function statusClass(status) { return `status-${String(status || '').toLowerCase().replaceAll(' ', '-')}`; }
function statusBadge(status) { return `<span class="status-badge ${statusClass(status)}">${escapeHtml(status || 'Pendiente')}</span>`; }

function render() {
  renderDate();
  renderDashboard();
  renderRequests();
  renderVehicles();
  renderLogs();
  renderUsers();
  renderDownloads();
  populateVehicleOptions();
  populateManualLogVehicles();
  updatePermissions();
}
function renderDate() {
  const now = new Date();
  const date = new Intl.DateTimeFormat('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
  document.querySelector('#todayLabel').textContent = new Intl.DateTimeFormat('es-MX', { day: 'numeric', month: 'short', year: 'numeric' }).format(now);
  document.querySelector('#dateStamp').textContent = date.charAt(0).toUpperCase() + date.slice(1);
}
function renderDashboard() {
  const inProgress = state.requests.filter(request => request.status === 'En curso').length;
  const pending = state.requests.filter(request => request.status === 'Pendiente').length;
  const available = state.vehicles.filter(vehicle => vehicle.availability === 'Disponible' && !state.requests.some(request => request.vehicleId === vehicle.id && request.status === 'En curso')).length;
  const stats = [['Solicitudes registradas', state.requests.length], ['Pendientes de autorización', pending], ['Unidades en traslado', inProgress], ['Vehículos disponibles', available]];
  document.querySelector('#dashboardStats').innerHTML = stats.map(([label, value]) => `<article class="stat-card"><span class="stat-label"><i class="stat-accent"></i>${label}</span><strong class="stat-value">${value}</strong></article>`).join('');
  const recent = [...state.requests].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')).slice(0, 5);
  document.querySelector('#recentRequestsBody').innerHTML = recent.map(request => `<tr><td><span class="folio">${escapeHtml(request.folio)}</span></td><td><span class="cell-primary">${escapeHtml(request.requester)}</span><span class="cell-secondary">${escapeHtml(request.driver)}</span></td><td>${escapeHtml(request.destination)}</td><td><span class="cell-primary">${formatDate(request.date)}</span><span class="cell-secondary">${escapeHtml(request.departure || 'Hora pendiente')}</span></td><td>${statusBadge(request.status)}</td><td><button class="small-action" type="button" data-edit-request="${escapeHtml(request.id)}">Editar</button></td></tr>`).join('');
  document.querySelector('#recentEmpty').classList.toggle('hidden', recent.length > 0);
  document.querySelector('#recentRequestsBody').closest('.table-wrap').classList.toggle('hidden', recent.length === 0);
  const busyCount = state.vehicles.filter(vehicle => state.requests.some(request => request.vehicleId === vehicle.id && request.status === 'En curso')).length;
  const maintenanceCount = state.vehicles.filter(vehicle => vehicle.availability === 'En mantenimiento').length;
  const availableCount = Math.max(0, state.vehicles.length - busyCount - maintenanceCount);
  document.querySelector('#fleetSummary').innerHTML = [['Disponible', availableCount, ''], ['En traslado', busyCount, 'busy'], ['En mantenimiento', maintenanceCount, 'maintenance']].map(([label, count, modifier]) => `<div class="fleet-line"><span class="fleet-line-label"><i class="fleet-mini-dot ${modifier}"></i>${label}</span><strong>${count}</strong></div>`).join('');
}
function renderRequests() {
  const query = document.querySelector('#requestSearch').value.trim().toLocaleLowerCase('es-MX');
  const status = document.querySelector('#statusFilter').value;
  const requests = [...state.requests].filter(request => {
    const vehicle = vehicleFor(request.vehicleId);
    const searchText = [request.folio, request.requester, request.driver, request.destination, vehicle?.unitNumber, vehicle?.plate].join(' ').toLocaleLowerCase('es-MX');
    return (!query || searchText.includes(query)) && (!status || request.status === status);
  }).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  document.querySelector('#requestsBody').innerHTML = requests.map(request => {
    const vehicle = vehicleFor(request.vehicleId);
    const km = request.kmOut !== '' && request.kmOut !== undefined ? `${escapeHtml(request.kmOut)}${request.kmIn !== '' && request.kmIn !== undefined ? ` → ${escapeHtml(request.kmIn)}` : ''}` : '—';
    const hours = [request.departure, request.arrival].filter(Boolean).join(' – ') || 'Horario pendiente';
    return `<tr><td><span class="folio">${escapeHtml(request.folio)}</span></td><td><span class="cell-primary">${escapeHtml(request.requester)}</span><span class="cell-secondary">${escapeHtml(request.driver)}${request.department ? ` · ${escapeHtml(request.department)}` : ''}</span></td><td>${vehicle ? `<span class="cell-primary">${escapeHtml(vehicleReference(vehicle))}</span><span class="cell-secondary">${escapeHtml(vehicle.model)} · ${escapeHtml(vehicle.color || 'Color sin registrar')}</span>` : '—'}</td><td>${escapeHtml(request.destination)}</td><td><span class="cell-primary">${formatDate(request.date)}</span><span class="cell-secondary">${escapeHtml(hours)}</span></td><td>${km}</td><td>${statusBadge(request.status)}</td><td><div class="row-actions"><button class="small-action" type="button" data-edit-request="${escapeHtml(request.id)}">Editar</button><button class="small-action danger" type="button" data-delete-request="${escapeHtml(request.id)}">Eliminar</button></div></td></tr>`;
  }).join('');
  const noResults = requests.length === 0;
  document.querySelector('#requestsEmpty').classList.toggle('hidden', !noResults);
  document.querySelector('#requestsBody').closest('.table-wrap').classList.toggle('hidden', noResults);
  document.querySelector('#requestsEmptyTitle').textContent = state.requests.length && (query || status) ? 'No hay resultados para este filtro' : 'No hay solicitudes registradas';
  document.querySelector('#requestsEmptyDescription').textContent = state.requests.length && (query || status) ? 'Prueba con otro término o estado.' : 'Cuando registres una solicitud, aparecerá aquí.';
  document.querySelector('#requestsEmpty [data-open-request]').classList.toggle('hidden', state.requests.length > 0);
}
function renderVehicles() {
  const busyIds = new Set(state.requests.filter(request => request.status === 'En curso').map(request => request.vehicleId));
  const available = state.vehicles.filter(vehicle => vehicle.availability === 'Disponible' && !busyIds.has(vehicle.id)).length;
  const busy = state.vehicles.filter(vehicle => busyIds.has(vehicle.id)).length;
  const maintenance = state.vehicles.filter(vehicle => vehicle.availability === 'En mantenimiento').length;
  document.querySelector('#fleetOverview').innerHTML = `<span><strong>${state.vehicles.length}</strong> unidades</span><span><strong>${available}</strong> disponibles</span><span><strong>${busy}</strong> en traslado</span><span><strong>${maintenance}</strong> en mantenimiento</span>`;
  document.querySelector('#vehicleGrid').innerHTML = state.vehicles.map(vehicle => {
    const isBusy = busyIds.has(vehicle.id);
    const availability = isBusy ? 'En traslado' : vehicle.availability;
    const badge = isBusy ? statusBadge('En curso') : `<span class="status-badge ${availability === 'Disponible' ? 'status-autorizado' : 'status-pendiente'}">${escapeHtml(availability)}</span>`;
    return `<article class="vehicle-card"><div class="vehicle-card-head"><div class="vehicle-identity"><span class="vehicle-number">UNIDAD ${escapeHtml(vehicle.unitNumber || 'S/N')}</span><span class="vehicle-plate">${escapeHtml(vehicle.plate)}</span></div>${badge}</div><h2 class="vehicle-model">${escapeHtml(vehicle.model)}</h2><span class="vehicle-type">${escapeHtml(vehicle.type || 'Tipo de unidad no especificado')}</span><div class="vehicle-description"><span>Color: ${escapeHtml(vehicle.color || 'Sin registrar')}</span><span>Combustible: ${escapeHtml(vehicle.fuelType || 'Sin registrar')}</span></div><div class="vehicle-meta"><span>Kilometraje actual</span><strong>${formatKm(vehicle.odometer)}</strong></div><div class="vehicle-actions"><button class="small-action" type="button" data-edit-vehicle="${escapeHtml(vehicle.id)}">Editar</button><button class="small-action danger" type="button" data-delete-vehicle="${escapeHtml(vehicle.id)}">Eliminar</button></div></article>`;
  }).join('');
  document.querySelector('#vehiclesEmpty').classList.toggle('hidden', state.vehicles.length > 0);
  document.querySelector('#vehicleGrid').classList.toggle('hidden', state.vehicles.length === 0);
}
function renderLogs() {
  const filter = document.querySelector('#logFilter').value;
  const logs = state.logs.filter(log => !filter || log.type === filter);
  document.querySelector('#logCount').textContent = `${logs.length} ${logs.length === 1 ? 'movimiento' : 'movimientos'}`;
  document.querySelector('#logBody').innerHTML = logs.map(log => {
    const attachments = (log.attachments || []).map(id => state.attachments.find(item => item.id === id)).filter(Boolean);
    const attachmentLinks = attachments.map(attachment => `<button class="attachment-download" type="button" data-download-attachment="${escapeHtml(attachment.id)}">Descargar: ${escapeHtml(attachment.fileName)}</button>`).join('');
    return `<tr><td>${formatDateTime(log.timestamp)}</td><td>${escapeHtml(log.type)}</td><td>${escapeHtml(log.user || 'Sistema')}</td><td><span class="folio">${escapeHtml(log.reference)}</span></td><td><span class="cell-primary">${escapeHtml(log.action)}</span></td><td>${escapeHtml(log.detail || '—')}${attachmentLinks ? `<div class="attachment-links">${attachmentLinks}</div>` : ''}</td></tr>`;
  }).join('');
  document.querySelector('#logEmpty').classList.toggle('hidden', logs.length > 0);
  document.querySelector('#logBody').closest('.table-wrap').classList.toggle('hidden', logs.length === 0);
}
function populateVehicleOptions(selectedId = '') {
  const select = document.querySelector('#requestVehicle');
  const options = state.vehicles.map(vehicle => {
    const inUse = state.requests.some(request => request.vehicleId === vehicle.id && request.status === 'En curso');
    const disabled = (vehicle.availability !== 'Disponible' || inUse) && vehicle.id !== selectedId;
    return `<option value="${escapeHtml(vehicle.id)}" ${vehicle.id === selectedId ? 'selected' : ''} ${disabled ? 'disabled' : ''}>No. ${escapeHtml(vehicle.unitNumber || 's/n')} · ${escapeHtml(vehicle.plate)} · ${escapeHtml(vehicle.model)}${disabled ? ' (no disponible)' : ''}</option>`;
  }).join('');
  select.innerHTML = `<option value="">Sin asignar</option>${options}`;
}
function populateManualLogVehicles() {
  const select = document.querySelector('#manualLogVehicle');
  const previous = select.value;
  select.innerHTML = `<option value="">Seleccionar unidad</option>${state.vehicles.map(vehicle => `<option value="${escapeHtml(vehicle.id)}">${escapeHtml(vehicleReference(vehicle))}</option>`).join('')}`;
  if (state.vehicles.some(vehicle => vehicle.id === previous)) select.value = previous;
  const scanSelect = document.querySelector('#scanVehicle');
  const scanPrevious = scanSelect.value;
  scanSelect.innerHTML = `<option value="">Seleccionar unidad</option>${state.vehicles.map(vehicle => `<option value="${escapeHtml(vehicle.id)}">${escapeHtml(vehicleReference(vehicle))}</option>`).join('')}`;
  if (state.vehicles.some(vehicle => vehicle.id === scanPrevious)) scanSelect.value = scanPrevious;
}
function renderUsers() {
  const labels = { admin: 'Administrador', capturista: 'Capturista de bitácora', consulta: 'Solo consulta' };
  document.querySelector('#usersBody').innerHTML = users.map(user => `<tr><td><span class="cell-primary">${escapeHtml(user.name)}</span></td><td>${escapeHtml(user.username)}</td><td>${escapeHtml(labels[user.role] || user.role)}</td><td><div class="row-actions">${user.id === currentUser?.id ? '<span class="current-user-label">Sesión actual</span>' : `<button class="small-action danger" type="button" data-delete-user="${escapeHtml(user.id)}">Eliminar</button>`}</div></td></tr>`).join('');
}
function renderDownloads() {
  const counts = [
    ['Solicitudes', state.requests.length],
    ['Vehículos', state.vehicles.length],
    ['Movimientos en bitácora', state.logs.length],
    ['Escaneos', state.attachments.length]
  ];
  document.querySelector('#downloadInventory').innerHTML = counts.map(([label, count]) => `<div class="download-count"><span>${label}</span><strong>${count}</strong></div>`).join('');
}
function updatePermissions() {
  const canManageUsers = currentUser?.role === 'admin';
  const canWriteLog = canManageUsers || currentUser?.role === 'capturista';
  document.querySelector('#usersNavItem').classList.toggle('hidden', !canManageUsers);
  document.querySelector('#manualLogForm').classList.toggle('hidden', !canWriteLog);
  document.querySelector('#scanUploadForm').classList.toggle('hidden', !canWriteLog);
  document.querySelector('#logPermissionLabel').textContent = currentUser ? `Captura: ${currentUser.name}` : '';
  document.querySelector('#sessionUser').textContent = currentUser ? `${currentUser.name} · ${currentUser.role === 'consulta' ? 'Consulta' : currentUser.role === 'capturista' ? 'Capturista' : 'Administrador'}` : '';
}
function showToast(message) {
  const toast = document.querySelector('#toast');
  toast.textContent = message;
  toast.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('visible'), 2600);
}
function showView(name) {
  if (name === 'users' && currentUser?.role !== 'admin') return;
  document.querySelectorAll('.view').forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
  document.querySelectorAll('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === name));
  const active = document.querySelector(`.nav-item[data-view="${name}"]`);
  document.querySelector('#breadcrumbCurrent').textContent = active?.textContent.trim().replace(/^\d+/, '') || 'Resumen';
}
function openRequest(request = null) {
  const form = document.querySelector('#requestForm');
  form.reset();
  document.querySelector('#requestError').classList.add('hidden');
  const data = request || { date: todayISO(), status: 'Pendiente' };
  for (const [key, value] of Object.entries(data)) if (form.elements.namedItem(key)) form.elements.namedItem(key).value = value ?? '';
  populateVehicleOptions(request?.vehicleId || '');
  document.querySelector('#requestDialogTitle').textContent = request ? `Editar ${request.folio}` : 'Nueva solicitud';
  document.querySelector('#requestDialog').showModal();
}
function openVehicle(vehicle = null) {
  const form = document.querySelector('#vehicleForm');
  form.reset();
  document.querySelector('#vehicleError').classList.add('hidden');
  for (const [key, value] of Object.entries(vehicle || {})) if (form.elements.namedItem(key)) form.elements.namedItem(key).value = value ?? '';
  document.querySelector('#vehicleDialogTitle').textContent = vehicle ? `Editar ${vehicle.plate}` : 'Agregar vehículo';
  document.querySelector('#vehicleDialog').showModal();
}
function hexToBytes(hex) { return new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16))); }
function bytesToHex(bytes) { return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(''); }
async function hashPassword(password, saltHex) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: hexToBytes(saltHex), iterations: 120000, hash: 'SHA-256' }, key, 256);
  return bytesToHex(new Uint8Array(bits));
}
function randomSalt() { return bytesToHex(crypto.getRandomValues(new Uint8Array(16))); }
function showAuth(mode) {
  document.querySelector('#authScreen').classList.remove('hidden');
  document.querySelector('#appShell').classList.add('hidden');
  document.querySelector('#setupAdminForm').classList.toggle('hidden', mode !== 'setup');
  document.querySelector('#loginForm').classList.toggle('hidden', mode !== 'login');
}
async function startSession(user) {
  currentUser = user;
  document.querySelector('#authScreen').classList.add('hidden');
  document.querySelector('#appShell').classList.remove('hidden');
  try {
    await refreshSharedState();
    showView('dashboard');
    clearInterval(liveRefreshTimer);
    liveRefreshTimer = setInterval(() => {
      if (!document.hidden) refreshSharedState().catch(error => showToast(error.message));
    }, 8000);
  } catch (error) {
    currentUser = null;
    showAuth('login');
    const loginError = document.querySelector('#loginError');
    loginError.textContent = error.message || 'No se pudo conectar con el servidor SICOPREV.';
    loginError.classList.remove('hidden');
  }
}
async function initializeAuth() {
  try {
    const status = await apiRequest('/api/status');
    if (!status.configured) { showAuth('setup'); return; }
    await startSession(await apiRequest('/api/me'));
  } catch (error) {
    showAuth('login');
    if (!error.message.includes('Inicia sesión')) {
      const loginError = document.querySelector('#loginError');
      loginError.textContent = 'No se pudo conectar con el servidor SICOPREV. Verifica que el servidor esté encendido.';
      loginError.classList.remove('hidden');
    }
  }
}
async function handleAdminSetup(event) {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  const error = document.querySelector('#setupError');
  error.classList.add('hidden');
  if (values.password !== values.confirmPassword) {
    error.textContent = 'Las contraseñas no coinciden.';
    error.classList.remove('hidden');
    return;
  }
  try {
    const user = await apiRequest('/api/setup', { method: 'POST', body: JSON.stringify({ name: values.name, username: values.username, password: values.password }) });
    const legacyChanges = {};
    for (const collection of ['requests', 'vehicles', 'logs', 'attachments']) {
      if (state[collection].length) legacyChanges[collection] = { upsert: state[collection], delete: [] };
    }
    if (Object.keys(legacyChanges).length) await apiRequest('/api/data', { method: 'POST', body: JSON.stringify({ changes: legacyChanges }) });
    localStorage.removeItem(STORAGE_KEY);
    await startSession(user);
  } catch {
    error.textContent = 'No fue posible crear el administrador. Verifica el servidor y usa una contraseña de 12 caracteres o más.';
    error.classList.remove('hidden');
  }
}
async function handleLogin(event) {
  event.preventDefault();
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  const error = document.querySelector('#loginError');
  error.classList.add('hidden');
  try {
    const user = await apiRequest('/api/login', { method: 'POST', body: JSON.stringify({ username: values.username, password: values.password }) });
    await startSession(user);
  } catch (loginError) {
    error.textContent = loginError.message || 'No fue posible validar el acceso.';
    error.classList.remove('hidden');
  }
}
async function handleUserSubmit(event) {
  event.preventDefault();
  if (currentUser?.role !== 'admin') return;
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  const username = values.username.trim().toLocaleLowerCase('es-MX');
  const error = document.querySelector('#userError');
  error.classList.add('hidden');
  if (users.some(user => user.username === username)) {
    error.textContent = 'Ese nombre de usuario ya existe.';
    error.classList.remove('hidden');
    return;
  }
  try {
    await apiRequest('/api/users', { method: 'POST', body: JSON.stringify({ name: values.name, username, password: values.password, role: values.role }) });
    users = await apiRequest('/api/users');
    renderUsers();
    document.querySelector('#userDialog').close();
    event.currentTarget.reset();
    showToast('Usuario creado.');
  } catch (userError) {
    error.textContent = userError.message || 'No fue posible guardar la cuenta en el servidor.';
    error.classList.remove('hidden');
  }
}
function updateManualLogInput() {
  const type = document.querySelector('#manualLogType').value;
  const input = document.querySelector('#manualLogValue');
  const labels = { Kilometraje: ['Kilometraje (km)', 'number', '1'], Gasolina: ['Gasolina (L)', 'number', '0.01'], 'Gas vehicular': ['Gas vehicular (m³)', 'number', '0.01'], Color: ['Color', 'text', ''], Observación: ['Descripción', 'text', ''] };
  const [label, inputType, step] = labels[type];
  document.querySelector('#manualLogValueLabel').innerHTML = `${label} <b>*</b>`;
  input.type = inputType;
  input.step = step;
  input.min = inputType === 'number' ? '0' : '';
  input.placeholder = type === 'Color' ? 'Ej. Blanco' : type === 'Observación' ? 'Describe el movimiento' : 'Escribe el valor';
}
function handleManualLogSubmit(event) {
  event.preventDefault();
  if (!['admin', 'capturista'].includes(currentUser?.role)) return;
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  const vehicle = vehicleFor(values.vehicleId);
  if (!vehicle) return;
  const value = values.value.trim();
  const numeric = Number(value);
  let detail = value;
  if (values.entryType === 'Kilometraje') {
    vehicle.odometer = numeric;
    detail = formatKm(numeric);
  } else if (values.entryType === 'Gasolina') {
    detail = `${new Intl.NumberFormat('es-MX', { maximumFractionDigits: 2 }).format(numeric)} L`;
  } else if (values.entryType === 'Gas vehicular') {
    detail = `${new Intl.NumberFormat('es-MX', { maximumFractionDigits: 2 }).format(numeric)} m³`;
  } else if (values.entryType === 'Color') {
    vehicle.color = value;
    detail = `Color: ${value}`;
  }
  addLog('Vehículo', vehicleReference(vehicle), `${values.entryType} capturado manualmente`, detail);
  persist();
  form.elements.namedItem('value').value = '';
  render();
  showView('log');
  showToast('Movimiento agregado a la bitácora.');
}
function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(new Error(`No se pudo leer ${file.name}.`));
    reader.readAsDataURL(file);
  });
}
async function handleScanUpload(event) {
  event.preventDefault();
  if (!['admin', 'capturista'].includes(currentUser?.role)) return;
  const form = event.currentTarget;
  const vehicle = vehicleFor(form.elements.namedItem('vehicleId').value);
  const files = Array.from(form.elements.namedItem('files').files || []);
  if (!vehicle || !files.length) return;
  if (files.some(file => file.size > 12000000 || !/\.(pdf|jpe?g|png)$/i.test(file.name))) {
    showToast('Elige archivos PDF, JPG o PNG de máximo 12 MB cada uno.');
    return;
  }
  const description = form.elements.namedItem('description').value.trim();
  const date = form.elements.namedItem('date').value;
  try {
    for (const file of files) {
      const attachment = await apiRequest('/api/attachments', {
        method: 'POST',
        body: JSON.stringify({ fileName: file.name, contentType: file.type, contentBase64: await readFileAsBase64(file) })
      });
      state.attachments.push(attachment);
      addLog('Escaneo', vehicleReference(vehicle), 'Bitácora física adjuntada', `${formatDate(date)} · ${description || file.name}`, [attachment.id]);
      await persist();
    }
    form.reset();
    form.elements.namedItem('date').value = todayISO();
    showToast(files.length === 1 ? 'Escaneo guardado en el servidor.' : 'Escaneos guardados en el servidor.');
  } catch (error) {
    showToast(error.message || 'No se pudo guardar el escaneo.');
  }
}
async function downloadAttachment(id) {
  try {
    const response = await fetch(`/api/attachments/${encodeURIComponent(id)}`, { credentials: 'same-origin' });
    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      throw new Error(payload.error || 'No se pudo descargar el escaneo.');
    }
    const attachment = state.attachments.find(item => item.id === id);
    const blob = await response.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = attachment?.fileName || 'bitacora-escaneada';
    link.click();
    URL.revokeObjectURL(link.href);
  } catch (error) {
    showToast(error.message || 'No se pudo descargar el escaneo.');
  }
}
async function logout() {
  await apiRequest('/api/logout', { method: 'POST' }).catch(() => {});
  clearInterval(liveRefreshTimer);
  currentUser = null;
  showAuth('login');
}
function handleRequestSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  const error = document.querySelector('#requestError');
  const kmOut = values.kmOut === '' ? '' : Number(values.kmOut);
  const kmIn = values.kmIn === '' ? '' : Number(values.kmIn);
  const gasolineLiters = values.gasolineLiters === '' ? '' : Number(values.gasolineLiters);
  const vehicleGasCubicMeters = values.vehicleGasCubicMeters === '' ? '' : Number(values.vehicleGasCubicMeters);
  if (kmOut !== '' && kmIn !== '' && kmIn < kmOut) {
    error.textContent = 'El kilometraje de llegada no puede ser menor al de salida.';
    error.classList.remove('hidden');
    return;
  }
  if (!STATUSES.includes(values.status)) return;
  const existing = state.requests.find(request => request.id === values.id);
  const vehicle = vehicleFor(values.vehicleId);
  if (values.vehicleId && !vehicle) {
    error.textContent = 'El vehículo seleccionado ya no está disponible en el inventario.';
    error.classList.remove('hidden');
    return;
  }
  const conflict = values.vehicleId && values.status === 'En curso' && state.requests.some(request => request.id !== values.id && request.vehicleId === values.vehicleId && request.status === 'En curso');
  if (conflict) {
    error.textContent = 'Este vehículo ya tiene un traslado en curso.';
    error.classList.remove('hidden');
    return;
  }
  const request = { ...values, id: existing?.id || makeId('REQ'), folio: existing?.folio || nextFolio(), kmOut, kmIn, gasolineLiters, vehicleGasCubicMeters, createdAt: existing?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
  const unitReference = vehicleReference(vehicle);
  const tripDetail = `${request.folio} · ${request.destination}`;
  if (existing) {
    Object.assign(existing, request);
    addLog('Solicitud', request.folio, 'Solicitud actualizada', `Estado: ${request.status}; destino: ${request.destination}; unidad: ${unitReference}`);
  } else {
    state.requests.unshift(request);
    addLog('Solicitud', request.folio, 'Solicitud registrada', `${request.requester}; destino: ${request.destination}; unidad: ${unitReference}`);
  }
  if (vehicle) addLog('Vehículo', unitReference, 'Unidad asignada', `${vehicle.plate}; ${vehicle.color || 'color sin registrar'}; combustible: ${vehicle.fuelType || 'sin registrar'}; ${tripDetail}`);
  if (kmOut !== '') addLog('Vehículo', unitReference, 'Kilometraje de salida', `${formatKm(kmOut)}; ${tripDetail}`);
  if (kmIn !== '') addLog('Vehículo', unitReference, 'Kilometraje de llegada', `${formatKm(kmIn)}; ${tripDetail}`);
  if (gasolineLiters !== '') addLog('Vehículo', unitReference, 'Gasolina registrada', `${new Intl.NumberFormat('es-MX', { maximumFractionDigits: 2 }).format(gasolineLiters)} L; ${tripDetail}`);
  if (vehicleGasCubicMeters !== '') addLog('Vehículo', unitReference, 'Gas vehicular registrado', `${new Intl.NumberFormat('es-MX', { maximumFractionDigits: 2 }).format(vehicleGasCubicMeters)} m³; ${tripDetail}`);
  if (vehicle && kmIn !== '') vehicle.odometer = kmIn;
  persist();
  render();
  document.querySelector('#requestDialog').close();
  showToast(existing ? 'Solicitud actualizada.' : `Solicitud ${request.folio} registrada.`);
}
function handleVehicleSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  values.unitNumber = values.unitNumber.trim();
  values.plate = values.plate.trim().toLocaleUpperCase('es-MX');
  values.odometer = values.odometer === '' ? '' : Number(values.odometer);
  const error = document.querySelector('#vehicleError');
  const duplicate = state.vehicles.some(vehicle => (vehicle.plate.toLocaleUpperCase('es-MX') === values.plate || vehicle.unitNumber?.toLocaleUpperCase('es-MX') === values.unitNumber.toLocaleUpperCase('es-MX')) && vehicle.id !== values.id);
  if (duplicate) {
    error.textContent = 'Ya existe un vehículo con ese número económico o esas placas.';
    error.classList.remove('hidden');
    return;
  }
  const existing = state.vehicles.find(vehicle => vehicle.id === values.id);
  const vehicle = { ...values, id: existing?.id || makeId('VEH') };
  const reference = vehicleReference(vehicle);
  if (existing) {
    const changes = [['unitNumber', 'Número económico'], ['plate', 'Placas'], ['model', 'Marca y modelo'], ['type', 'Tipo de unidad'], ['color', 'Color'], ['fuelType', 'Combustible'], ['odometer', 'Kilometraje'], ['availability', 'Disponibilidad']];
    for (const [key, label] of changes) {
      if (String(existing[key] ?? '') !== String(vehicle[key] ?? '')) addLog('Vehículo', reference, `${label} actualizado`, `Antes: ${existing[key] || 'sin registrar'}; ahora: ${vehicle[key] || 'sin registrar'}`);
    }
    Object.assign(existing, vehicle);
  } else {
    state.vehicles.unshift(vehicle);
    addLog('Vehículo', reference, 'Vehículo registrado', `${vehicle.model}; placas ${vehicle.plate}`);
    addLog('Vehículo', reference, 'Color registrado', vehicle.color);
    addLog('Vehículo', reference, 'Combustible registrado', vehicle.fuelType);
    addLog('Vehículo', reference, 'Kilometraje registrado', formatKm(vehicle.odometer));
  }
  persist();
  render();
  document.querySelector('#vehicleDialog').close();
  showToast(existing ? 'Vehículo actualizado.' : 'Vehículo agregado al inventario.');
}
function exportRequests() {
  if (!state.requests.length) { showToast('No hay solicitudes para exportar.'); return; }
  const columns = ['Folio', 'Solicitante', 'Área', 'Conductor', 'Teléfono', 'Licencia', 'Número económico', 'Placas', 'Marca y modelo', 'Color', 'Combustible', 'Destino', 'Fecha', 'Hora salida', 'Hora llegada', 'Kilometraje salida', 'Kilometraje llegada', 'Gasolina (L)', 'Gas vehicular (m³)', 'Estado', 'Motivo'];
  const rows = state.requests.map(request => {
    const vehicle = vehicleFor(request.vehicleId);
    return [request.folio, request.requester, request.department, request.driver, request.phone, request.license, vehicle?.unitNumber, vehicle?.plate, vehicle?.model, vehicle?.color, vehicle?.fuelType, request.destination, request.date, request.departure, request.arrival, request.kmOut, request.kmIn, request.gasolineLiters, request.vehicleGasCubicMeters, request.status, request.reason];
  });
  const csv = [columns, ...rows].map(row => row.map(value => `"${String(value ?? '').replaceAll('"', '""')}"`).join(',')).join('\r\n');
  const blob = new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `sicoprev-solicitudes-${todayISO()}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  showToast('Archivo CSV descargado.');
}
function downloadExcelWorkbook() {
  if (!window.XLSX) {
    showToast('No se pudo cargar el módulo de Excel. Revisa tu conexión a internet e inténtalo de nuevo.');
    return;
  }
  const requestRows = [[
    'Folio', 'Solicitante', 'Área', 'Conductor', 'Teléfono', 'Licencia', 'Número económico', 'Placas', 'Marca y modelo', 'Color', 'Combustible', 'Destino', 'Fecha', 'Hora salida', 'Hora llegada', 'Kilometraje salida', 'Kilometraje llegada', 'Gasolina (L)', 'Gas vehicular (m³)', 'Estado', 'Motivo'
  ], ...state.requests.map(request => {
    const vehicle = vehicleFor(request.vehicleId);
    return [request.folio, request.requester, request.department, request.driver, request.phone, request.license, vehicle?.unitNumber, vehicle?.plate, vehicle?.model, vehicle?.color, vehicle?.fuelType, request.destination, request.date, request.departure, request.arrival, request.kmOut, request.kmIn, request.gasolineLiters, request.vehicleGasCubicMeters, request.status, request.reason];
  })];
  const vehicleRows = [[
    'Número económico', 'Placas', 'Marca y modelo', 'Tipo de unidad', 'Color', 'Combustible', 'Kilometraje actual', 'Disponibilidad'
  ], ...state.vehicles.map(vehicle => [vehicle.unitNumber, vehicle.plate, vehicle.model, vehicle.type, vehicle.color, vehicle.fuelType, vehicle.odometer, vehicle.availability])];
  const logRows = [[
    'Fecha y hora', 'Tipo', 'Usuario', 'Folio / unidad', 'Movimiento', 'Detalle'
  ], ...state.logs.map(log => [formatDateTime(log.timestamp), log.type, log.user || 'Sistema', log.reference, log.action, log.detail])];
  const attachmentRows = [[
    'Archivo', 'Unidad / referencia', 'Fecha de carga', 'Subido por', 'Detalle de bitácora'
  ], ...state.attachments.map(attachment => {
    const log = state.logs.find(item => (item.attachments || []).includes(attachment.id));
    return [attachment.fileName, log?.reference, formatDateTime(attachment.uploadedAt), attachment.uploadedBy, log?.detail];
  })];
  const workbook = XLSX.utils.book_new();
  for (const [name, rows] of [['Solicitudes', requestRows], ['Vehículos', vehicleRows], ['Bitácora', logRows], ['Escaneos', attachmentRows]]) {
    const sheet = XLSX.utils.aoa_to_sheet(rows);
    sheet['!cols'] = rows[0].map((heading, index) => {
      const contentWidth = Math.max(String(heading).length, ...rows.slice(1, 21).map(row => String(row[index] ?? '').length));
      return { wch: Math.min(42, Math.max(14, contentWidth + 2)) };
    });
    XLSX.utils.book_append_sheet(workbook, sheet, name);
  }
  XLSX.writeFile(workbook, `SICOPREV_${todayISO()}.xlsx`);
  showToast('Libro de Excel descargado.');
}

document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click', () => showView(button.dataset.view)));
document.querySelectorAll('[data-go-view]').forEach(button => button.addEventListener('click', () => showView(button.dataset.goView)));
document.querySelector('#newRequestButton').addEventListener('click', () => openRequest());
document.querySelectorAll('[data-open-request]').forEach(button => button.addEventListener('click', () => openRequest()));
document.querySelector('#newVehicleButton').addEventListener('click', () => openVehicle());
document.querySelectorAll('[data-open-vehicle]').forEach(button => button.addEventListener('click', () => openVehicle()));
document.querySelectorAll('[data-close-dialog]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
document.querySelector('#requestForm').addEventListener('submit', handleRequestSubmit);
document.querySelector('#vehicleForm').addEventListener('submit', handleVehicleSubmit);
document.querySelector('#setupAdminForm').addEventListener('submit', handleAdminSetup);
document.querySelector('#loginForm').addEventListener('submit', handleLogin);
document.querySelector('#userForm').addEventListener('submit', handleUserSubmit);
document.querySelector('#manualLogForm').addEventListener('submit', handleManualLogSubmit);
document.querySelector('#scanUploadForm').addEventListener('submit', handleScanUpload);
document.querySelector('#scanDate').value = todayISO();
document.querySelector('#manualLogType').addEventListener('change', updateManualLogInput);
document.querySelector('#logoutButton').addEventListener('click', logout);
document.querySelector('#newUserButton').addEventListener('click', () => {
  if (currentUser?.role !== 'admin') return;
  document.querySelector('#userForm').reset();
  document.querySelector('#userError').classList.add('hidden');
  document.querySelector('#userDialog').showModal();
});
document.querySelector('#requestSearch').addEventListener('input', renderRequests);
document.querySelector('#statusFilter').addEventListener('change', renderRequests);
document.querySelector('#logFilter').addEventListener('change', renderLogs);
document.querySelector('#exportButton').addEventListener('click', exportRequests);
document.querySelector('#downloadExcelButton').addEventListener('click', downloadExcelWorkbook);
document.addEventListener('click', event => {
  const downloadAttachmentButton = event.target.closest('[data-download-attachment]');
  if (downloadAttachmentButton) {
    downloadAttachment(downloadAttachmentButton.dataset.downloadAttachment);
    return;
  }
  const deleteUser = event.target.closest('[data-delete-user]');
  if (deleteUser) {
    if (currentUser?.role !== 'admin') return;
    const user = users.find(account => account.id === deleteUser.dataset.deleteUser);
    if (!user || user.id === currentUser.id) return;
    if (window.confirm(`¿Eliminar el acceso de ${user.name}?`)) {
      apiRequest(`/api/users/${encodeURIComponent(user.id)}`, { method: 'DELETE' }).then(async () => {
        users = await apiRequest('/api/users');
        renderUsers();
        showToast('Acceso eliminado.');
      }).catch(error => showToast(error.message));
    }
    return;
  }
  const editRequest = event.target.closest('[data-edit-request]');
  if (editRequest) {
    const request = state.requests.find(item => item.id === editRequest.dataset.editRequest);
    if (request) openRequest(request);
    return;
  }
  const deleteRequest = event.target.closest('[data-delete-request]');
  if (deleteRequest) {
    const request = state.requests.find(item => item.id === deleteRequest.dataset.deleteRequest);
    if (request && window.confirm(`¿Eliminar la solicitud ${request.folio}? Esta acción no se puede deshacer.`)) {
      state.requests = state.requests.filter(item => item.id !== request.id);
      addLog('Solicitud', request.folio, 'Solicitud eliminada', `${request.requester}; destino: ${request.destination}`);
      persist(); render(); showToast('Solicitud eliminada.');
    }
    return;
  }
  const editVehicle = event.target.closest('[data-edit-vehicle]');
  if (editVehicle) {
    const vehicle = vehicleFor(editVehicle.dataset.editVehicle);
    if (vehicle) openVehicle(vehicle);
    return;
  }
  const deleteVehicle = event.target.closest('[data-delete-vehicle]');
  if (deleteVehicle) {
    const vehicle = vehicleFor(deleteVehicle.dataset.deleteVehicle);
    const assigned = state.requests.some(request => request.vehicleId === vehicle?.id);
    if (!vehicle) return;
    if (assigned) { showToast('No se puede eliminar: hay solicitudes vinculadas a esta unidad.'); return; }
    if (window.confirm(`¿Eliminar el vehículo ${vehicle.plate}? Esta acción no se puede deshacer.`)) {
      state.vehicles = state.vehicles.filter(item => item.id !== vehicle.id);
      addLog('Vehículo', vehicleReference(vehicle), 'Vehículo eliminado', `${vehicle.model}; ${vehicle.color || 'color sin registrar'}; combustible: ${vehicle.fuelType || 'sin registrar'}`);
      persist(); render(); showToast('Vehículo eliminado.');
    }
  }
});

render();
updateManualLogInput();
initializeAuth();